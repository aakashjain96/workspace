package com.capgemini.flp.service;

import java.util.Optional;

import com.capgemini.flp.bean.Product;

public interface ProductService {

	public Optional<Product> getProductById(int id);
	
}
