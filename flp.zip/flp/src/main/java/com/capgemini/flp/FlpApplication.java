package com.capgemini.flp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages="com.capgemini.flp")
public class FlpApplication {

	public static void main(String[] args) {
		SpringApplication.run(FlpApplication.class, args);
	}
}
