package com.capgemini.flp.repo;

import java.util.Optional;

import com.capgemini.flp.bean.Product;

public class ProductRepoImpl {

	public Optional<Product> findById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

}
