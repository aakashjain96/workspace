package com.cg.session.service;

import java.util.List;


import com.cg.session.dto.ScheduledSessions;

public interface ITrainingService {
	
	public List<ScheduledSessions> showSessions();

}
