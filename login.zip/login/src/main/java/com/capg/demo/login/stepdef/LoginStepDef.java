package com.capg.demo.login.stepdef;

import org.apache.log4j.Logger;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.capg.demo.login.bean.LoginBean;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginStepDef {

	static Logger logger = Logger.getLogger(LoginStepDef.class.getName());
	static WebDriver driver;
	static LoginBean pagebean;
	
	@Before
	public void init()
	{
		System.setProperty("webdriver.chrome.driver", "D:\\devops\\selenium\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		
	}
	
	@Given("^I have username and password$")
	public void i_have_username_and_password() throws Throwable {
	
		
		pagebean=new LoginBean();
		driver.get("http://localhost:8084/seleniumweb/login.html");
		PageFactory.initElements(driver, pagebean);
		pagebean.setUsername("aakash");
		pagebean.setPassword("balleballe");
		pagebean.setGender("male");
		pagebean.setSel("ten");
	
		
	}

	@When("^I enter username and password$")
	public void i_enter_username_and_password() throws Throwable {
	 

		pagebean.buttonclick();
	}

	@Then("^I login into the page$")
	public void i_login_into_the_page() throws Throwable {
	    System.out.println("succesfull");
	}
	
}
