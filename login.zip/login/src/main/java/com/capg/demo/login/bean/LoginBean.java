package com.capg.demo.login.bean;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.Select;

public class LoginBean {

	@FindBy(how=How.ID,id="username")
	private WebElement username;
	
	@FindBy(how=How.ID,id="password")
	private WebElement password;
	
	@FindBy(how=How.ID,id="submit")
	private WebElement submit;
	
	@FindBy(how=How.NAME , name="gender")
	private List<WebElement> gender;
	
	@FindBy(how=How.ID,id="sel")
	private WebElement selec;
	
	public void buttonclick()
	{
		submit.click();
	}
	
	@FindBy(how=How.ID,id="cancel")
	private WebElement cancel;

	public String getUsername() {
		return username.getAttribute("value");
	}

	public void setUsername(String username) {
		this.username.sendKeys(username);;
	}

	public String getPassword() {
		return password.getAttribute("value");
	}

	public void setPassword(String password) {
		this.password.sendKeys(password);;
	}

	public String getGender() {
		for (WebElement webElement : gender) 
			if(webElement.isSelected())
				return webElement.getAttribute("value");
			return null;
	}

	public void setGender(String gender) {
		if(gender.equals("male"))
			this.gender.get(0).click();
		else if(gender.equals("female"))
			this.gender.get(1).click();
	}

	public String getSel() {
		return new Select(selec).getFirstSelectedOption().getText();
	}

	public void setSel(String selec) {
		new Select(this.selec).selectByVisibleText(selec);
	}

	
	
	
	
}
