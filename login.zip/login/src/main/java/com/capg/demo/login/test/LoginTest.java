package com.capg.demo.login.test;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
		features= {"features"},
		glue= {"com.capg.demo.login.stepdef"},
		tags= {"@execute"}
	)
public class LoginTest {

}
